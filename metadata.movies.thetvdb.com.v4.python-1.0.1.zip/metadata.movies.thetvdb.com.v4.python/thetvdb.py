#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from resources.lib import actions

actions.run()
